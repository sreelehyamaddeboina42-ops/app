import React, { useEffect, useRef, useState } from 'react';
import { Trophy, Home } from 'lucide-react';
import { audioService } from '../services/audioService';

interface Props {
  onGameOver: (score: number) => void;
  highScore: number;
  onExit: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
}

const SpaceClusterGame: React.FC<Props> = ({ onGameOver, highScore, onExit }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameOver, setGameOver] = useState(false);
  const [scoreDisplay, setScoreDisplay] = useState(0);

  // Game state refs for loop (mutable for performance)
  const gameState = useRef({
    isPlaying: true,
    playerX: 50, // Percentage 0-100
    obstacles: [] as { x: number; y: number; type: 'asteroid' | 'satellite'; size: number }[],
    particles: [] as Particle[],
    speed: 0.9, // vertical speed % per frame (Increased base speed)
    score: 0,
    lastScoreSound: 0,
    lastThrusterTime: 0, // Track time for engine sound throttling
    frames: 0
  });

  const requestRef = useRef<number>(0);

  // Start game on mount
  useEffect(() => {
    // Initial setup
    if(canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
    }
    
    startGame();
    audioService.resume(); 
    
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const startGame = () => {
    setGameOver(false);
    setScoreDisplay(0);
    
    // Completely reset state
    gameState.current = {
      isPlaying: true,
      playerX: 50,
      obstacles: [],
      particles: [],
      speed: 0.9,
      score: 0,
      lastScoreSound: 0,
      lastThrusterTime: 0,
      frames: 0
    };

    // Ensure we don't have multiple loops running
    if (requestRef.current) cancelAnimationFrame(requestRef.current);
    
    // Start loop immediately
    loop();
  };

  const createExplosion = (x: number, y: number) => {
    for(let i = 0; i < 40; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 2 + 1;
        gameState.current.particles.push({
            x: x,
            y: y,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            life: 1.0,
            color: ['#EF4444', '#F59E0B', '#FFFFFF', '#FCD34D'][Math.floor(Math.random() * 4)],
            size: Math.random() * 6 + 2
        });
    }
  };

  // Helper to play thruster sound without spamming it during drags
  const triggerThruster = () => {
      const now = Date.now();
      // Only play every 150ms to create a pulsing engine effect rather than machine gun
      if (now - gameState.current.lastThrusterTime > 150) {
          audioService.playThruster();
          gameState.current.lastThrusterTime = now;
      }
  };

  const loop = () => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    // Continue loop even if game over to show explosion animation, 
    // but stop logic updates for game
    if (!gameState.current.isPlaying && gameState.current.particles.length === 0) return;

    const width = canvasRef.current.width;
    const height = canvasRef.current.height;

    // --- LOGIC ---
    if (gameState.current.isPlaying) {
        // Update State
        gameState.current.frames++;
        gameState.current.score += 0.1;
        
        // Thruster Particles (Trail)
        if (gameState.current.frames % 2 === 0) {
            gameState.current.particles.push({
                x: gameState.current.playerX + (Math.random() - 0.5) * 2, // Jitter x slightly (percentage)
                y: 93, // Bottom of ship (percentage)
                vx: (Math.random() - 0.5) * 0.2,
                vy: Math.random() * 1 + 0.5, // Move down
                life: 1.0,
                color: Math.random() > 0.5 ? '#38BDF8' : '#F59E0B', // Blue/Orange thrust
                size: Math.random() * 3 + 1
            });
        }

        // Update score display and play sound every 50 points
        const currentScoreInt = Math.floor(gameState.current.score);
        setScoreDisplay(currentScoreInt);
        
        if (currentScoreInt > 0 && currentScoreInt % 50 === 0 && currentScoreInt !== gameState.current.lastScoreSound) {
            audioService.playScore();
            gameState.current.lastScoreSound = currentScoreInt;
        }
        
        // Increase difficulty slowly
        if (gameState.current.frames % 300 === 0) {
          gameState.current.speed += 0.05;
        }

        // Spawn obstacles
        // Reduced base from 60 to 50, min from 20 to 15 for faster spawns
        const spawnRate = Math.max(15, 50 - Math.floor(gameState.current.score / 50));
        if (gameState.current.frames % spawnRate === 0) {
        const size = 5 + Math.random() * 5; // 5-10% width
        gameState.current.obstacles.push({
            x: Math.random() * (100 - size), // Random X
            y: -15, // Start above screen
            type: Math.random() > 0.8 ? 'satellite' : 'asteroid',
            size: size
        });
        }

        // Move obstacles
        gameState.current.obstacles.forEach(obs => {
          obs.y += gameState.current.speed;
        });

        // Clean up off-screen
        gameState.current.obstacles = gameState.current.obstacles.filter(obs => obs.y < 120);

        // Collision Detection
        const playerW = 6; // %
        const playerH = 8; // %
        const playerY = 85; // Fixed Y position %
        
        let hit = false;
        
        const pLeft = gameState.current.playerX - playerW/2;
        const pRight = gameState.current.playerX + playerW/2;
        const pTop = playerY;
        const pBottom = playerY + playerH;

        gameState.current.obstacles.forEach(obs => {
        const obsLeft = obs.x;
        const obsRight = obs.x + obs.size;
        const obsTop = obs.y;
        const obsBottom = obs.y + obs.size; 

        // Simple box collision
        if (pLeft < obsRight && pRight > obsLeft && pTop < obsBottom && pBottom > obsTop) {
            // Refined check for circles/irregular shapes (simple inset)
            const inset = 1; 
            if ((pLeft+inset) < (obsRight-inset) && (pRight-inset) > (obsLeft+inset) && 
                (pTop+inset) < (obsBottom-inset) && (pBottom-inset) > (obsTop+inset)) {
                    hit = true;
            }
        }
        });

        if (hit) {
            handleGameOver();
        }
    }

    // Update Particles (always run)
    gameState.current.particles.forEach(p => {
        p.x += p.vx * 0.5; // Scale velocity for percentage/pixel conversion roughly
        p.y += p.vy; // Vy is usually % based for consistency with game objects? 
        
        p.life -= 0.02;
        p.size *= 0.95;
    });
    gameState.current.particles = gameState.current.particles.filter(p => p.life > 0);


    // --- DRAW ---
    ctx.clearRect(0, 0, width, height);
    
    // Note: Background is handled by Starfield component behind this canvas,
    // but the container div has a tint.

    // Obstacles
    gameState.current.obstacles.forEach(obs => {
        const x = (obs.x / 100) * width;
        const y = (obs.y / 100) * height;
        const s = (obs.size / 100) * width;
        
        if (obs.type === 'asteroid') {
            ctx.fillStyle = '#888';
            ctx.beginPath();
            ctx.arc(x + s/2, y + s/2, s/2, 0, Math.PI*2);
            ctx.fill();
            // Craters details
            ctx.fillStyle = '#666';
            ctx.beginPath();
            ctx.arc(x + s/3, y + s/3, s/5, 0, Math.PI*2);
            ctx.fill();
            ctx.beginPath();
            ctx.arc(x + s*0.7, y + s*0.6, s/6, 0, Math.PI*2);
            ctx.fill();
        } else {
            // Satellite debris
            ctx.save();
            ctx.translate(x + s/2, y + s/2);
            ctx.rotate(gameState.current.frames * 0.05);
            ctx.fillStyle = '#FFD700'; // Gold body
            ctx.fillRect(-s/2, -s/4, s, s/2);
            ctx.fillStyle = '#AAA'; // Panels
            ctx.fillRect(-s, -s/6, s/2, s/3);
            ctx.fillRect(s/2, -s/6, s/2, s/3);
            ctx.restore();
        }
    });

    // Particles
    gameState.current.particles.forEach(p => {
        const px = (p.x / 100) * width;
        const py = (p.y / 100) * height;
        
        ctx.globalAlpha = p.life;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(px, py, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
    });

    // Player (Astronaut/Ship) - Always draw if playing to ensure not blank
    if (gameState.current.isPlaying) {
        const playerW = 6;
        const playerH = 8;
        const playerY = 85;
        
        const px = (gameState.current.playerX / 100) * width;
        const py = (playerY / 100) * height;
        const pw = (playerW / 100) * width;
        
        ctx.save();
        ctx.translate(px, py + pw); // Pivot at center
        
        // Engine Glow
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#38BDF8';

        // Body
        ctx.fillStyle = '#E2E8F0';
        ctx.beginPath();
        ctx.ellipse(0, 0, pw/2, pw/1.5, 0, 0, Math.PI*2);
        ctx.fill();
        
        // Wings/Fins
        ctx.fillStyle = '#94A3B8';
        ctx.beginPath();
        ctx.moveTo(-pw/2, 0);
        ctx.lineTo(-pw, pw/1.5);
        ctx.lineTo(-pw/2, pw/2);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(pw/2, 0);
        ctx.lineTo(pw, pw/1.5);
        ctx.lineTo(pw/2, pw/2);
        ctx.fill();
        
        ctx.shadowBlur = 0;

        // Visor
        ctx.fillStyle = '#38BDF8';
        ctx.beginPath();
        ctx.ellipse(0, -pw/4, pw/3, pw/4, 0, 0, Math.PI*2);
        ctx.fill();
        
        // Reflection on visor
        ctx.fillStyle = 'rgba(255,255,255,0.8)';
        ctx.beginPath();
        ctx.ellipse(-pw/6, -pw/3, pw/8, pw/10, 0, 0, Math.PI*2);
        ctx.fill();
        
        ctx.restore();
    }

    requestRef.current = requestAnimationFrame(loop);
  };

  const handleGameOver = () => {
    if (gameState.current.isPlaying) { // Prevent double trigger
        audioService.playExplosion();
        gameState.current.isPlaying = false;
        
        // Spawn big explosion at player position
        createExplosion(gameState.current.playerX, 85 + 4);

        setGameOver(true);
        onGameOver(Math.floor(gameState.current.score));
    }
  };

  // Input Handling
  const handleTouchMove = (e: React.TouchEvent) => {
    if (gameOver) return;
    const touch = e.touches[0];
    const width = window.innerWidth;
    const x = (touch.clientX / width) * 100;
    gameState.current.playerX = Math.max(5, Math.min(95, x));
    triggerThruster();
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (gameOver) return;
    if (e.buttons > 0) {
        const width = window.innerWidth;
        const x = (e.clientX / width) * 100;
        gameState.current.playerX = Math.max(5, Math.min(95, x));
        triggerThruster();
    }
  };

  // Keyboard fallback
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (gameOver) return;
        
        if (e.key === 'ArrowLeft') {
            gameState.current.playerX = Math.max(5, gameState.current.playerX - 5);
            triggerThruster();
        }
        if (e.key === 'ArrowRight') {
            gameState.current.playerX = Math.min(95, gameState.current.playerX + 5);
            triggerThruster();
        }
    };
    window.addEventListener('keydown', handleKeyDown);

    const handleResize = () => {
        if(canvasRef.current) {
            canvasRef.current.width = window.innerWidth;
            canvasRef.current.height = window.innerHeight;
        }
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
        window.removeEventListener('keydown', handleKeyDown);
        window.removeEventListener('resize', handleResize);
        if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameOver]);

  const handleAction = (cb: () => void) => {
      audioService.playClick();
      cb();
  };

  return (
    <div className="relative w-full h-full touch-none select-none bg-slate-900/10">
        <canvas 
            ref={canvasRef} 
            className="block w-full h-full cursor-crosshair" 
            onTouchMove={handleTouchMove}
            onMouseMove={handleMouseMove}
        />
        
        {/* UI Overlay */}
        <div className="absolute top-4 left-4 text-white font-bold text-xl drop-shadow-md z-10 pointer-events-none">
            SCORE: {scoreDisplay}
        </div>

        {!gameOver && gameState.current.score < 10 && (
            <div className="absolute bottom-10 w-full text-center text-white/50 animate-pulse pointer-events-none">
                Drag or use Arrows to move
            </div>
        )}

        {/* Game Over Screen */}
        {gameOver && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-md z-20">
                <div className="text-center animate-in fade-in zoom-in duration-300">
                    <h2 className="text-5xl font-black text-red-500 mb-2 drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]">GAME OVER</h2>
                    <div className="text-2xl text-white mb-6">Final Score: {scoreDisplay}</div>
                    
                    {scoreDisplay > highScore && (
                        <div className="mb-8 animate-bounce text-yellow-400 flex flex-col items-center">
                            <Trophy size={48} />
                            <span className="text-xl font-bold">New High Score!</span>
                        </div>
                    )}

                    <div className="flex flex-col gap-4 w-64 mx-auto">
                        <button 
                            onClick={() => handleAction(onExit)}
                            onMouseEnter={() => audioService.playHover()}
                            className="flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-slate-700 hover:bg-slate-600 transition text-white font-bold shadow-lg"
                        >
                            <Home size={20}/> Return Home
                        </button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default SpaceClusterGame;