import React, { useState, useRef } from 'react';
import { Upload, Video, Loader2, Home, Info } from 'lucide-react';
import { generateVideoWithVeo } from '../services/geminiService';

interface Props {
  onBack: () => void;
}

const VeoGenerator: React.FC<Props> = ({ onBack }) => {
  const [image, setImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [resultVideo, setResultVideo] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setMimeType(file.type);
        setResultVideo(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!image) return;
    setLoading(true);
    try {
      const base64Data = image.split(',')[1];
      const videoUrl = await generateVideoWithVeo(base64Data, mimeType, prompt);
      setResultVideo(videoUrl);
    } catch (error: any) {
      console.error("Video Gen Error", error);
      alert("Failed to generate video: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8 flex flex-col items-center relative overflow-y-auto">
      <button onClick={onBack} className="absolute top-4 left-4 p-2 bg-slate-800 rounded-full text-white hover:bg-slate-700 z-50">
        <Home size={24} />
      </button>

      <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-400 mb-2 mt-12 md:mt-0 text-center">
        Veo Motion Lab
      </h1>
      <p className="text-slate-400 mb-8 max-w-lg text-center">
        Bring your static space photos to life with AI video generation.
      </p>

      <div className="w-full max-w-xl bg-slate-900/90 border border-slate-700 p-6 rounded-2xl backdrop-blur-md shadow-2xl">
        
        {/* Upload Area */}
        <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-full h-48 border-2 border-dashed border-slate-600 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-teal-500 hover:bg-slate-800/50 transition mb-6 relative overflow-hidden"
          >
            {image ? (
              <img src={image} alt="Source" className="w-full h-full object-cover opacity-80" />
            ) : (
              <div className="text-slate-400 text-center flex flex-col items-center gap-2">
                <Upload size={32} />
                <p>Upload Image to Animate</p>
              </div>
            )}
             <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
        </div>

        {/* Prompt */}
        <div className="mb-6">
            <label className="block text-slate-300 text-sm font-bold mb-2">Animation Prompt (Optional)</label>
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. Cinematic zoom, slow motion spin..."
              className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:outline-none focus:border-teal-500"
            />
        </div>

        {/* Action */}
        <button
            onClick={handleGenerate}
            disabled={!image || loading}
            className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
              !image || loading 
                ? 'bg-slate-700 text-slate-500 cursor-not-allowed' 
                : 'bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-400 hover:to-blue-500 text-white shadow-[0_0_20px_rgba(20,184,166,0.3)]'
            }`}
          >
            {loading ? <Loader2 className="animate-spin" /> : <Video />}
            {loading ? 'Generating Video (may take 60s)...' : 'Generate Video'}
          </button>

          {/* Result */}
          {resultVideo && (
            <div className="mt-8 animate-in fade-in slide-in-from-bottom-4">
                <h3 className="text-lg font-bold text-white mb-2">Generated Video</h3>
                <video controls className="w-full rounded-lg border border-teal-500/50 shadow-lg" autoPlay loop>
                    <source src={resultVideo} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
                 <a 
                    href={resultVideo} 
                    download="veo-creation.mp4"
                    className="mt-4 py-2 w-full rounded-lg font-bold bg-slate-700 hover:bg-slate-600 text-white flex items-center justify-center gap-2 transition"
                >
                    Download MP4
                </a>
            </div>
          )}
          
          <div className="mt-4 p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg flex gap-3 text-xs text-blue-200 items-start">
             <Info size={16} className="shrink-0 mt-0.5" />
             <p>This feature requires a paid API key via Google AI Studio. You may be prompted to select a key project.</p>
          </div>
      </div>
    </div>
  );
};

export default VeoGenerator;
