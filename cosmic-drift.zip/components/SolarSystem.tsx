import React, { useState, useEffect } from 'react';
import { ZoomIn, ZoomOut, Home } from 'lucide-react';
import { PLANETS } from '../constants';
import { Planet } from '../types';
import { audioService } from '../services/audioService';

interface Props {
  onBack: () => void;
}

const SolarSystem: React.FC<Props> = ({ onBack }) => {
  // Initialize scale smaller on mobile to fit the orbits
  const [scale, setScale] = useState(0.6);
  const [selectedPlanet, setSelectedPlanet] = useState<Planet | null>(null);

  useEffect(() => {
    // Responsive initial zoom
    if (window.innerWidth < 768) {
        setScale(0.4);
    }
  }, []);

  const handleZoom = (delta: number) => {
    audioService.playWhoosh();
    setScale(prev => Math.min(Math.max(0.2, prev + delta), 2.5));
  };

  const handlePlanetSelect = (planet: Planet) => {
      audioService.playClick();
      audioService.playWhoosh();
      setSelectedPlanet(planet);
  };

  const closePlanet = () => {
      audioService.playClick();
      setSelectedPlanet(null);
  };

  const handleBack = () => {
      audioService.playClick();
      onBack();
  };

  const getPlanetStyle = (planet: Planet) => {
    const baseShadow = `inset -4px -4px 8px rgba(0,0,0,0.9), inset 2px 2px 4px rgba(255,255,255,0.3), 0 0 10px ${planet.color}40`;
    
    let background = planet.color;

    switch(planet.name) {
        case 'Mercury':
            // Gray/brown cratered look
            background = 'radial-gradient(circle at 60% 20%, #bfbfbf 5%, transparent 10%), radial-gradient(circle at 30% 30%, #e0e0e0, #5a5a5a)';
            break;
        case 'Venus':
            // Thick atmosphere, yellow/orange swirls
            background = 'linear-gradient(45deg, #e6cd8e, #c7a448, #e6cd8e)';
            break;
        case 'Earth':
            // Blue water, green land masses, white clouds
            background = `
                radial-gradient(circle at 70% 20%, rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 10%), 
                radial-gradient(circle at 30% 60%, #2ecc71 0%, transparent 15%), 
                radial-gradient(circle at 70% 40%, #2ecc71 0%, transparent 15%), 
                radial-gradient(circle at 30% 30%, #4F86F7, #07387a)
            `;
            break;
        case 'Mars':
            // Red with polar ice cap
            background = 'radial-gradient(circle at 50% 5%, #fff 0%, transparent 8%), radial-gradient(circle at 30% 30%, #e74c3c, #801515)';
            break;
        case 'Jupiter':
             // Distinct bands
             background = 'linear-gradient(180deg, #6b5042 0%, #a8917e 10%, #d6cdb8 20%, #a8917e 30%, #6b5042 45%, #a8917e 55%, #d6cdb8 70%, #a8917e 85%, #6b5042 100%)';
             break;
        case 'Saturn':
             // Pale gold bands
             background = 'linear-gradient(180deg, #bca886 0%, #e3dccb 20%, #bca886 40%, #e3dccb 60%, #bca886 100%)';
             break;
        case 'Uranus':
             // Pale cyan, smooth
             background = 'radial-gradient(circle at 30% 30%, #d1f3fa, #4aa6b5)';
             break;
        case 'Neptune':
             // Deep blue, smooth
             background = 'radial-gradient(circle at 30% 30%, #5dade2, #102a45)';
             break;
    }

    return {
      background,
      boxShadow: baseShadow,
      width: planet.size,
      height: planet.size,
      backgroundSize: '200% 200%' 
    };
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black/20">
      
      {/* Controls */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 z-20 safe-area-inset-top safe-area-inset-left">
        <button onClick={handleBack} onMouseEnter={() => audioService.playHover()} className="p-3 bg-slate-800/80 rounded-full text-white hover:bg-slate-700 backdrop-blur-md transition hover:scale-110 shadow-lg border border-slate-700">
          <Home size={24} />
        </button>
      </div>

      <div className="absolute bottom-8 right-4 flex flex-col gap-2 z-20 safe-area-inset-bottom safe-area-inset-right">
         <button onClick={() => handleZoom(0.1)} onMouseEnter={() => audioService.playHover()} className="p-3 bg-slate-800/80 rounded-full text-white hover:bg-slate-700 backdrop-blur-md transition hover:scale-110 shadow-lg border border-slate-700">
          <ZoomIn size={24} />
        </button>
        <button onClick={() => handleZoom(-0.1)} onMouseEnter={() => audioService.playHover()} className="p-3 bg-slate-800/80 rounded-full text-white hover:bg-slate-700 backdrop-blur-md transition hover:scale-110 shadow-lg border border-slate-700">
          <ZoomOut size={24} />
        </button>
      </div>

      {/* Solar System Container - Centered */}
      <div 
        className="absolute top-1/2 left-1/2 transition-transform duration-300 ease-out"
        style={{ transform: `translate(-50%, -50%) scale(${scale})` }}
      >
        {/* Sun */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28 rounded-full shadow-[0_0_100px_rgba(255,140,0,0.8)] z-10">
             <div className="w-full h-full rounded-full bg-[radial-gradient(circle_at_40%_40%,#fff2cc,#ffcc00,#ff8c00,#ff4500)] animate-pulse-slow" />
        </div>

        {/* Orbits and Planets */}
        {PLANETS.map((planet, index) => (
          <div
            key={planet.name}
            className="absolute top-1/2 left-1/2 rounded-full border border-white/10 pointer-events-none"
            style={{
              width: planet.orbitRadius * 2,
              height: planet.orbitRadius * 2,
              marginLeft: -planet.orbitRadius,
              marginTop: -planet.orbitRadius,
              animation: `spin ${planet.speed * 2}s linear infinite`,
              animationDelay: `-${index * 85}s` // Scatter start positions
            }}
          >
            {/* Planet Container - Counter Rotated to keep upright */}
            <div 
              className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-20 pointer-events-auto"
              style={{ 
                animation: `counter-spin ${planet.speed * 2}s linear infinite`,
                animationDelay: `-${index * 85}s`
              }}
            >
                <div className="relative flex flex-col items-center">
                    <div 
                      className="rounded-full relative hover:scale-125 transition-transform duration-300"
                      style={getPlanetStyle(planet)}
                      onClick={() => handlePlanetSelect(planet)}
                      onMouseEnter={() => audioService.playHover()}
                    >
                        {/* Saturn Ring */}
                        {planet.name === 'Saturn' && (
                            <div 
                                className="absolute top-1/2 left-1/2 rounded-full border-[6px] border-[#c4b5a3]/60 shadow-[0_0_0_2px_rgba(0,0,0,0.1)] pointer-events-none" 
                                style={{ 
                                    width: '180%', 
                                    height: '180%', 
                                    transform: 'translate(-50%, -50%) rotate(20deg) scaleY(0.4)' 
                                }}
                            />
                        )}
                    </div>
                    
                    {/* Planet Name Label (Always Visible) */}
                    <div className="mt-2 px-2 py-0.5 rounded bg-black/40 backdrop-blur-sm text-[10px] text-white/80 font-bold tracking-widest uppercase border border-white/10 shadow-sm pointer-events-none">
                        {planet.name}
                    </div>

                    {/* Tooltip Description on Hover (Desktop only mainly) */}
                    <div className="hidden md:block absolute -top-24 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none z-50 transform translate-y-4 group-hover:translate-y-0 w-48 text-center">
                        <div 
                          className="bg-slate-900/95 border px-3 py-2 rounded-xl shadow-[0_0_30px_rgba(0,0,0,0.5)] backdrop-blur-md"
                          style={{ borderColor: planet.color }}
                        >
                            <span className="text-white font-bold text-sm block">{planet.name}</span>
                            <span className="text-xs text-slate-300 leading-tight block mt-1">
                              {planet.shortDescription}
                            </span>
                        </div>
                    </div>
                </div>

            </div>
          </div>
        ))}
      </div>

      {/* Planet Info Modal */}
      {selectedPlanet && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-md z-50 p-4 animate-in fade-in duration-200" onClick={closePlanet}>
          <div 
            className="bg-slate-900 border border-slate-600 p-6 md:p-8 rounded-3xl w-[90vw] max-w-sm shadow-[0_0_50px_rgba(0,0,0,0.8)] relative transform transition-all scale-100 overflow-visible mt-12"
            onClick={e => e.stopPropagation()}
          >
            <div className="absolute -top-12 left-1/2 -translate-x-1/2">
                 <div 
                    className="rounded-full shadow-[0_0_40px_rgba(0,0,0,0.5)] animate-bounce-slow"
                    style={{
                        ...getPlanetStyle(selectedPlanet),
                        width: 80,
                        height: 80
                    }}
                 >
                    {selectedPlanet.name === 'Saturn' && (
                         <div 
                            className="absolute top-1/2 left-1/2 rounded-full border-[8px] border-[#c4b5a3]/80 pointer-events-none" 
                            style={{ 
                                width: '180%', 
                                height: '180%', 
                                transform: 'translate(-50%, -50%) rotate(20deg) scaleY(0.4)' 
                            }}
                        />
                    )}
                 </div>
            </div>
            
            <div className="mt-10 text-center">
                <h2 className="text-3xl font-black text-white mb-2 tracking-tight">{selectedPlanet.name}</h2>
                <p 
                  className="font-bold text-xs md:text-sm uppercase tracking-widest mb-4"
                  style={{ color: selectedPlanet.color }}
                >
                  {selectedPlanet.shortDescription}
                </p>
                
                <p className="text-slate-300 text-base md:text-lg leading-relaxed border-t border-slate-700/50 pt-4">
                {selectedPlanet.description}
                </p>
            </div>

            <div className="mt-6 flex justify-center">
              <button 
                onClick={closePlanet}
                className="px-6 py-2 md:px-8 md:py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-full font-bold shadow-lg transition transform hover:scale-105"
              >
                Close Explorer
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes counter-spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(-360deg); }
        }
        .animate-spin-slow {
            animation: spin 60s linear infinite;
        }
        .animate-bounce-slow {
            animation: bounce 3s infinite;
        }
        .animate-pulse-slow {
            animation: pulse 4s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
};

export default SolarSystem;