import React, { useEffect, useRef, useState } from 'react';
import { Trophy, Home } from 'lucide-react';
import { audioService } from '../services/audioService';

interface Props {
  onGameOver: (score: number) => void;
  highScore: number;
  onExit: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  size: number;
  color: string;
}

const MoonRoverGame: React.FC<Props> = ({ onGameOver, highScore, onExit }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameOver, setGameOver] = useState(false);
  const [scoreDisplay, setScoreDisplay] = useState(0);

  // Game State
  const gameState = useRef({
    isPlaying: true,
    roverX: 50, // % horizontal
    speed: 0.75, // vertical speed (Increased from 0.66)
    craters: [] as { x: number; y: number; size: number }[],
    particles: [] as Particle[],
    score: 0,
    lastScoreSound: 0,
    frames: 0
  });
  
  const requestRef = useRef<number>(0);

  useEffect(() => {
    startGame();
    audioService.resume();
    return () => {
        cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const startGame = () => {
    setGameOver(false);
    setScoreDisplay(0);
    gameState.current = {
      isPlaying: true,
      roverX: 50,
      speed: 0.75, // Reset to increased speed
      craters: [],
      particles: [],
      score: 0,
      lastScoreSound: 0,
      frames: 0
    };
    if (requestRef.current) cancelAnimationFrame(requestRef.current);
    loop();
  };

  const loop = () => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    
    const width = canvasRef.current.width;
    const height = canvasRef.current.height;
    
    // --- UPDATE ---
    if (gameState.current.isPlaying) {
        gameState.current.frames++;
        gameState.current.score += 0.1;
        
        const currentScore = Math.floor(gameState.current.score);
        setScoreDisplay(currentScore);
        
        // Score sound every 50m
        if (currentScore > 0 && currentScore % 50 === 0 && currentScore !== gameState.current.lastScoreSound) {
            audioService.playScore();
            gameState.current.lastScoreSound = currentScore;
        }

        // Increase speed
        if (gameState.current.frames % 500 === 0) gameState.current.speed += 0.1;

        // Spawn Craters
        // Reduced base from 70 to 60, min from 25 to 20 for faster spawns
        const spawnRate = Math.max(20, 60 - Math.floor(gameState.current.score / 20));
        if (gameState.current.frames % spawnRate === 0) {
            const size = 10 + Math.random() * 10; // 10-20% width
            gameState.current.craters.push({
                x: Math.random() * (100 - size),
                y: -20,
                size: size
            });
        }

        // Dust Particles (Wheel Kickup)
        if (gameState.current.frames % 4 === 0) {
            // Left Wheel
            gameState.current.particles.push({
                x: gameState.current.roverX - 3, 
                y: 88,
                vx: (Math.random() - 0.5) * 0.5,
                vy: Math.random() * 1 + 1, // Move down (away)
                life: 1.0,
                size: Math.random() * 4 + 2,
                color: '#aaaaaa'
            });
            // Right Wheel
            gameState.current.particles.push({
                x: gameState.current.roverX + 3, 
                y: 88,
                vx: (Math.random() - 0.5) * 0.5,
                vy: Math.random() * 1 + 1,
                life: 1.0,
                size: Math.random() * 4 + 2,
                color: '#aaaaaa'
            });
        }
    }

    if (!gameState.current.isPlaying) {
        // Just draw last frame
    } else {
        // Move Craters
        gameState.current.craters.forEach(c => c.y += gameState.current.speed);
        gameState.current.craters = gameState.current.craters.filter(c => c.y < 120);

        // Move Particles
        gameState.current.particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy; // They move down with the ground
            p.life -= 0.03;
            p.size *= 0.95;
        });
        gameState.current.particles = gameState.current.particles.filter(p => p.life > 0);

        // Collision Check
        checkCollision();
    }

    // --- DRAW ---
    ctx.clearRect(0, 0, width, height);

    // 1. Background / Surface
    const surfaceGrad = ctx.createLinearGradient(0, 0, 0, height);
    surfaceGrad.addColorStop(0, '#1a1a20'); // Darker at top (distance)
    surfaceGrad.addColorStop(1, '#303038'); // Lighter at bottom
    ctx.fillStyle = surfaceGrad;
    ctx.fillRect(0, 0, width, height);

    // 2. Perspective Grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 2;
    
    // Longitudinal lines (Vertical-ish)
    const vpX = width / 2;

    for(let i = -width; i < width * 2; i+=width/8) {
        ctx.beginPath();
        const spread = 0.4; // How much it spreads at bottom vs top
        const xTop = vpX + (i - vpX) * spread;
        const xBot = i;
        ctx.moveTo(xTop, 0);
        ctx.lineTo(xBot, height);
        ctx.stroke();
    }

    // Latitudinal lines (Horizontal moving)
    const numLines = 10;
    const scrollPhase = (gameState.current.frames * 0.02 * gameState.current.speed) % 1;
    
    for(let j = 0; j < numLines; j++) {
        const depth = (j + scrollPhase) / numLines; // 0 to 1
        const y = Math.pow(depth, 1.5) * height;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
    }

    // 3. Craters
    gameState.current.craters.forEach(c => {
        const cx = (c.x/100) * width;
        const cy = (c.y/100) * height;
        const cw = (c.size/100) * width;
        const ch = cw * 0.6; // Perspective squish

        // Crater interior (shadow)
        const craterGrad = ctx.createRadialGradient(cx + cw/2, cy + ch/2, 0, cx + cw/2, cy + ch/2, cw/2);
        craterGrad.addColorStop(0.7, '#111');
        craterGrad.addColorStop(1, '#444');

        ctx.fillStyle = craterGrad;
        ctx.beginPath();
        ctx.ellipse(cx + cw/2, cy + ch/2, cw/2, ch/2, 0, 0, Math.PI*2);
        ctx.fill();
        
        // Crater rim highlight (bottom edge lit)
        ctx.strokeStyle = '#666';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx + cw/2, cy + ch/2, cw/2, Math.PI * 0.8, Math.PI * 2.2); 
        ctx.stroke();
    });

    // 4. Particles (Dust)
    gameState.current.particles.forEach(p => {
        const px = (p.x / 100) * width;
        const py = (p.y / 100) * height;
        const ps = (p.size / 100) * width * 0.5;

        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life * 0.5;
        ctx.beginPath();
        ctx.arc(px, py, ps, 0, Math.PI*2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
    });

    // 5. Rover
    if (gameState.current.isPlaying) {
        drawRover(ctx, width, height);
    }

    if(gameState.current.isPlaying) {
        requestRef.current = requestAnimationFrame(loop);
    }
  };

  const drawRover = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const roverW = 8; 
    const roverH = 10; 
    const roverY = 80;

    const rx = (gameState.current.roverX/100) * width;
    const ry = (roverY/100) * height;
    const rw = (roverW/100) * width;
    const rh = (roverH/100) * height;

    ctx.save();
    ctx.translate(rx, ry + rh/2);
    
    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.beginPath();
    ctx.ellipse(0, rh/2, rw/1.5, rh/4, 0, 0, Math.PI*2);
    ctx.fill();

    // Wheels (Suspension wobble?)
    const wobble = Math.sin(gameState.current.frames * 0.5) * 2;
    ctx.translate(0, wobble);

    // Body Color
    ctx.fillStyle = '#E2E8F0';
    ctx.fillRect(-rw/2, -rh/2, rw, rh);
    
    // Tech Details
    ctx.fillStyle = '#334155';
    ctx.fillRect(-rw/3, -rh/3, rw/1.5, rh/2);
    
    // Wheels (Treads)
    const treadOffset = (gameState.current.frames % 10) * (rh/30);
    
    ctx.fillStyle = '#111';
    // Draw wheel blocks
    const drawWheel = (wx: number, wy: number) => {
        ctx.fillStyle = '#222';
        ctx.fillRect(wx, wy, rw/4, rh/3);
        // Treads
        ctx.fillStyle = '#444';
        for(let t=0; t<3; t++) {
           const ty = wy + ((t * 8 + gameState.current.frames*2) % (rh/3));
           if(ty < wy + rh/3 - 2) {
             ctx.fillRect(wx, ty, rw/4, 2);
           }
        }
    };

    drawWheel(-rw*0.75, -rh/2); // FL
    drawWheel(rw*0.5, -rh/2);   // FR
    drawWheel(-rw*0.75, rh/6);  // RL
    drawWheel(rw*0.5, rh/6);    // RR

    // Headlights (Beams)
    ctx.globalCompositeOperation = 'screen';
    const grad = ctx.createLinearGradient(0, -rh/2, 0, -rh*3);
    grad.addColorStop(0, 'rgba(250, 204, 21, 0.4)');
    grad.addColorStop(1, 'rgba(250, 204, 21, 0)');
    
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(-rw/4, -rh/2);
    ctx.lineTo(-rw, -rh*3);
    ctx.lineTo(0, -rh*3);
    ctx.fill();
    
    ctx.beginPath();
    ctx.moveTo(rw/4, -rh/2);
    ctx.lineTo(rw, -rh*3);
    ctx.lineTo(0, -rh*3);
    ctx.fill();
    ctx.globalCompositeOperation = 'source-over';

    // Light Sources
    ctx.fillStyle = '#FACC15';
    ctx.beginPath();
    ctx.arc(-rw/4, -rh/2, rw/8, 0, Math.PI*2);
    ctx.arc(rw/4, -rh/2, rw/8, 0, Math.PI*2);
    ctx.fill();
    
    // Red Tail lights
    ctx.fillStyle = '#EF4444';
    ctx.fillRect(-rw/3, rh/2 - 2, 3, 3);
    ctx.fillRect(rw/3 - 3, rh/2 - 2, 3, 3);

    ctx.restore();
  };

  const checkCollision = () => {
    const roverW = 8;
    const roverH = 10;
    const roverY = 80;
    
    const rLeft = gameState.current.roverX - roverW/2;
    const rRight = gameState.current.roverX + roverW/2;
    const rTop = roverY;
    const rBottom = roverY + roverH;

    let crash = false;
    gameState.current.craters.forEach(c => {
        const cLeft = c.x;
        const cRight = c.x + c.size;
        const cTop = c.y;
        const cBottom = c.y + (c.size * 0.6); 

        // Hitbox padding to be forgiving
        const pad = 1;

        if ((rLeft+pad) < cRight && (rRight-pad) > cLeft && (rTop+pad) < cBottom && (rBottom-pad) > cTop) {
            // Distance check
            const cCenterX = c.x + c.size/2;
            const cCenterY = c.y + (c.size * 0.3);
            const rCenterX = gameState.current.roverX;
            const rCenterY = roverY + roverH/2;
            
            const dx = (rCenterX - cCenterX);
            const dy = (rCenterY - cCenterY) * 2; 
            const dist = Math.sqrt(dx*dx + dy*dy);
            
            if (dist < (c.size/2 + roverW/3)) {
                crash = true;
            }
        }
    });

    if (crash) {
        handleGameOver();
    }
  };

  const handleGameOver = () => {
    audioService.playExplosion();
    gameState.current.isPlaying = false;
    setGameOver(true);
    onGameOver(Math.floor(gameState.current.score));
  };

  // Input
  const handleTouchMove = (e: React.TouchEvent) => {
    if (gameOver) return;
    const touch = e.touches[0];
    const width = window.innerWidth;
    const x = (touch.clientX / width) * 100;
    gameState.current.roverX = Math.max(5, Math.min(95, x));
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (gameOver) return;
    if (e.buttons > 0) {
        const width = window.innerWidth;
        const x = (e.clientX / width) * 100;
        gameState.current.roverX = Math.max(5, Math.min(95, x));
    }
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
        if (gameOver) return;
        if(e.key === 'ArrowLeft') {
            gameState.current.roverX = Math.max(5, gameState.current.roverX - 5);
            audioService.playRoverMove();
        }
        if(e.key === 'ArrowRight') {
            gameState.current.roverX = Math.min(95, gameState.current.roverX + 5);
            audioService.playRoverMove();
        }
    };
    window.addEventListener('keydown', handleKey);
    
    const handleResize = () => {
        if(canvasRef.current) {
            canvasRef.current.width = window.innerWidth;
            canvasRef.current.height = window.innerHeight;
        }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    
    return () => {
        window.removeEventListener('keydown', handleKey);
        window.removeEventListener('resize', handleResize);
        if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameOver]);

  const handleAction = (cb: () => void) => {
      audioService.playClick();
      cb();
  };

  return (
    <div className="relative w-full h-full touch-none select-none">
        <canvas 
            ref={canvasRef} 
            className="block w-full h-full cursor-crosshair" 
            onTouchMove={handleTouchMove}
            onMouseMove={handleMouseMove}
        />
        
        <div className="absolute top-4 left-4 text-white font-bold text-xl drop-shadow-md z-10 pointer-events-none">
            DISTANCE: {scoreDisplay}m
        </div>

        {!gameOver && gameState.current.score < 10 && (
            <div className="absolute bottom-10 w-full text-center text-white/50 animate-pulse pointer-events-none">
                Drag to steer Rover
            </div>
        )}

        {gameOver && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-md z-20">
                <div className="text-center animate-in fade-in zoom-in duration-300">
                    <h2 className="text-5xl font-black text-red-500 mb-2">CRASHED!</h2>
                    <div className="text-2xl text-white mb-6">Distance: {scoreDisplay}m</div>
                    {scoreDisplay > highScore && (
                         <div className="mb-8 animate-bounce text-yellow-400 flex flex-col items-center">
                            <Trophy size={48} />
                            <span className="text-xl font-bold">New Record!</span>
                        </div>
                    )}
                     <div className="flex flex-col gap-4 w-64 mx-auto">
                        <button 
                            onClick={() => handleAction(onExit)}
                            onMouseEnter={() => audioService.playHover()}
                            className="flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-slate-700 hover:bg-slate-600 transition text-white font-bold shadow-lg"
                        >
                            <Home size={20}/> Return Home
                        </button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default MoonRoverGame;