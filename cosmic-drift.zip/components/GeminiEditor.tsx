import React, { useState, useRef } from 'react';
import { Upload, Sparkles, Loader2, Home, Download } from 'lucide-react';
import { editImageWithGemini } from '../services/geminiService';

interface Props {
  onBack: () => void;
}

const GeminiEditor: React.FC<Props> = ({ onBack }) => {
  const [image, setImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setMimeType(file.type);
        setResultImage(null); // reset result
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!image || !prompt) return;
    setLoading(true);
    try {
      // Clean base64 string for API (remove "data:image/xyz;base64,")
      const base64Data = image.split(',')[1];
      const result = await editImageWithGemini(base64Data, mimeType, prompt);
      setResultImage(result);
    } catch (error) {
      console.error("Editing failed", error);
      alert("Failed to edit image. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8 flex flex-col items-center relative overflow-y-auto">
      <button onClick={onBack} className="absolute top-4 left-4 p-2 bg-slate-800 rounded-full text-white hover:bg-slate-700 z-50">
        <Home size={24} />
      </button>

      <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-8 mt-12 md:mt-0 text-center">
        Cosmic AI Editor
      </h1>

      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column: Input */}
        <div className="bg-slate-900/80 border border-slate-700 p-6 rounded-2xl backdrop-blur-sm">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <Upload size={20} /> Upload Source
          </h2>
          
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-full h-64 border-2 border-dashed border-slate-600 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-purple-500 hover:bg-slate-800/50 transition relative overflow-hidden group"
          >
            {image ? (
              <img src={image} alt="Source" className="w-full h-full object-contain" />
            ) : (
              <div className="text-slate-400 text-center">
                <p>Click to upload image</p>
                <span className="text-xs opacity-50">JPG, PNG supported</span>
              </div>
            )}
            <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                accept="image/*" 
                className="hidden" 
            />
          </div>

          <div className="mt-6">
            <label className="block text-slate-300 text-sm font-bold mb-2">Magic Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="E.g., 'Turn the sky purple' or 'Add a spaceship in the background'"
              className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:outline-none focus:border-purple-500 h-24 resize-none"
            />
          </div>

          <button
            onClick={handleGenerate}
            disabled={!image || !prompt || loading}
            className={`w-full mt-4 py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition ${
              !image || !prompt || loading 
                ? 'bg-slate-700 text-slate-500 cursor-not-allowed' 
                : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-lg shadow-purple-900/20'
            }`}
          >
            {loading ? <Loader2 className="animate-spin" /> : <Sparkles />}
            {loading ? 'Processing Cosmic Magic...' : 'Generate Edit'}
          </button>
        </div>

        {/* Right Column: Output */}
        <div className="bg-slate-900/80 border border-slate-700 p-6 rounded-2xl backdrop-blur-sm flex flex-col">
          <h2 className="text-xl font-bold text-white mb-4">Result</h2>
          <div className="flex-1 min-h-[300px] border border-slate-700 rounded-xl bg-black/40 flex items-center justify-center overflow-hidden relative">
            {resultImage ? (
              <img src={resultImage} alt="Edited Result" className="w-full h-full object-contain" />
            ) : (
              <div className="text-slate-600 italic">Result will appear here...</div>
            )}
          </div>
           {resultImage && (
             <a 
                href={resultImage} 
                download="cosmic-edit.png"
                className="mt-4 py-3 rounded-lg font-bold bg-green-600 hover:bg-green-500 text-white flex items-center justify-center gap-2 transition"
             >
                <Download size={20} /> Save Image
             </a>
           )}
        </div>
      </div>
    </div>
  );
};

export default GeminiEditor;
