import { GoogleGenAI } from "@google/genai";

// Helper to get client with current key
const getClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// --- Image Editing (Gemini 2.5 Flash Image) ---
export const editImageWithGemini = async (
  base64Image: string,
  mimeType: string,
  prompt: string
): Promise<string> => {
  const ai = getClient();
  
  // Construct parts: Image + Text Prompt
  const parts = [
    {
      inlineData: {
        data: base64Image,
        mimeType: mimeType,
      },
    },
    {
      text: prompt,
    },
  ];

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: parts,
    },
    // No responseMimeType needed for image generation/edit usually, 
    // but the output will contain the image in the parts.
  });

  // Extract the image from the response
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  
  throw new Error("No image returned from Gemini.");
};

// --- Video Generation (Veo) ---
export const generateVideoWithVeo = async (
  base64Image: string,
  mimeType: string,
  prompt?: string
): Promise<string> => {
  
  // 1. Check for API Key Selection (Mandatory for Veo)
  // @ts-ignore - aistudio is injected by the environment
  if (window.aistudio && typeof window.aistudio.hasSelectedApiKey === 'function') {
      // @ts-ignore
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
          // @ts-ignore
          await window.aistudio.openSelectKey();
          // We assume success if they come back, but we can't verify easily without re-triggering.
          // Proceed to try generation.
      }
  }

  // 2. Create fresh client after potential key selection
  const ai = getClient();

  // 3. Start Operation
  // Determine aspect ratio based on prompt or default to 16:9 if not specified?
  // User prompt implies general usage. We will default to 16:9 for landscape feel.
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: prompt || "Animate this image cinematically", 
    image: {
      imageBytes: base64Image,
      mimeType: mimeType,
    },
    config: {
      numberOfVideos: 1,
      // Prompt requirement: 16:9 or 9:16. Let's pick 16:9 for web.
      aspectRatio: '16:9',
      resolution: '720p', // fast-generate-preview supports 720p usually or 1080p? Docs say 720p/1080p for `generateVideos` but fast might be limited. Stick to standard example.
    }
  });

  // 4. Poll for completion
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 5000)); // Poll every 5s
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  // 5. Get Result
  const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!videoUri) {
    throw new Error("Video generation failed or returned no URI.");
  }

  // 6. Fetch the actual video bytes using the key
  const videoResponse = await fetch(`${videoUri}&key=${process.env.API_KEY}`);
  if (!videoResponse.ok) {
     throw new Error("Failed to download generated video.");
  }
  
  const videoBlob = await videoResponse.blob();
  return URL.createObjectURL(videoBlob);
};
