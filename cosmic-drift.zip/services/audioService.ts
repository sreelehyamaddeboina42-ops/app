class AudioService {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private droneGain: GainNode | null = null;
  public isMuted: boolean = false;
  private initialized: boolean = false;

  init() {
    if (this.initialized) return;
    try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        this.ctx = new AudioContextClass();
        this.masterGain = this.ctx.createGain();
        this.masterGain.connect(this.ctx.destination);
        this.masterGain.gain.value = 0.3; // Default volume
        this.initialized = true;
    } catch (e) {
        console.error("Audio init failed", e);
    }
  }

  resume() {
    try {
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    } catch (e) {
        console.error("Audio resume failed", e);
    }
  }

  toggleMute() {
    if (!this.ctx || !this.masterGain) return true;
    this.isMuted = !this.isMuted;
    
    try {
        // Smooth fade
        const t = this.ctx.currentTime;
        const target = this.isMuted ? 0 : 0.3;
        this.masterGain.gain.cancelScheduledValues(t);
        this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, t);
        this.masterGain.gain.linearRampToValueAtTime(target, t + 0.2);
    } catch (e) {
        console.error("Toggle mute failed", e);
    }
    
    return this.isMuted;
  }

  private safely(fn: () => void) {
      try {
          fn();
      } catch (e) {
          console.warn("Audio Error:", e);
      }
  }

  // --- Ambient Space Drone ---
  startAmbience() {
    this.safely(() => {
        if (!this.ctx || !this.masterGain || this.droneGain) return;
        
        this.droneGain = this.ctx.createGain();
        this.droneGain.gain.value = 0.2;
        this.droneGain.connect(this.masterGain);

        const osc1 = this.ctx.createOscillator();
        osc1.type = 'sine';
        osc1.frequency.value = 55; // A1
        
        const osc2 = this.ctx.createOscillator();
        osc2.type = 'triangle';
        osc2.frequency.value = 55.5; 
        
        const lfo = this.ctx.createOscillator();
        lfo.type = 'sine';
        lfo.frequency.value = 0.1;
        const lfoGain = this.ctx.createGain();
        lfoGain.gain.value = 100;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 300;

        lfo.connect(lfoGain);
        lfoGain.connect(filter.frequency);

        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(this.droneGain);

        osc1.start();
        osc2.start();
        lfo.start();
    });
  }

  // --- UI Sounds ---
  playHover() {
    this.safely(() => {
        if (!this.ctx || !this.masterGain) return;
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, t);
        osc.frequency.exponentialRampToValueAtTime(1200, t + 0.05);
        
        gain.gain.setValueAtTime(0.05, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
        
        osc.connect(gain);
        gain.connect(this.masterGain);
        
        osc.start();
        osc.stop(t + 0.05);
    });
  }

  playClick() {
    this.safely(() => {
        if (!this.ctx || !this.masterGain) return;
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(600, t);
        osc.frequency.exponentialRampToValueAtTime(200, t + 0.15);
        
        gain.gain.setValueAtTime(0.1, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
        
        osc.connect(gain);
        gain.connect(this.masterGain);
        
        osc.start();
        osc.stop(t + 0.15);
    });
  }

  // --- Game Sounds ---

  playThruster() {
    this.safely(() => {
        if (!this.ctx || !this.masterGain) return;
        const t = this.ctx.currentTime;
        
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(80, t);
        osc.frequency.linearRampToValueAtTime(40, t + 0.15);
        
        gain.gain.setValueAtTime(0.1, t);
        gain.gain.linearRampToValueAtTime(0, t + 0.15);
        
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 400;

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.masterGain);
        
        osc.start();
        osc.stop(t + 0.15);
    });
  }

  playRoverMove() {
     this.safely(() => {
         if (!this.ctx || !this.masterGain) return;
         const t = this.ctx.currentTime;
         
         const osc = this.ctx.createOscillator();
         const gain = this.ctx.createGain();
         
         osc.type = 'square';
         osc.frequency.setValueAtTime(60, t);
         osc.frequency.linearRampToValueAtTime(50, t + 0.1);
         
         gain.gain.setValueAtTime(0.08, t);
         gain.gain.linearRampToValueAtTime(0, t + 0.1);
         
         const filter = this.ctx.createBiquadFilter();
         filter.type = 'lowpass';
         filter.frequency.value = 200;
     
         osc.connect(filter);
         filter.connect(gain);
         gain.connect(this.masterGain);
         
         osc.start();
         osc.stop(t + 0.1);
     });
  }

  playScore() {
    this.safely(() => {
        if (!this.ctx || !this.masterGain) return;
        const t = this.ctx.currentTime;
        
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, t);
        osc.frequency.setValueAtTime(1800, t + 0.05); // Jump pitch
        
        gain.gain.setValueAtTime(0.1, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
        
        osc.connect(gain);
        gain.connect(this.masterGain);
        
        osc.start();
        osc.stop(t + 0.3);
    });
  }

  playExplosion() {
    this.safely(() => {
        if (!this.ctx || !this.masterGain) return;
        const t = this.ctx.currentTime;
        
        const createNoiseOsc = (freq: number) => {
            const osc = this.ctx!.createOscillator();
            const gain = this.ctx!.createGain();
            osc.type = 'sawtooth';
            osc.frequency.value = freq;
            osc.frequency.exponentialRampToValueAtTime(10, t + 0.5);
            gain.gain.setValueAtTime(0.3, t);
            gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
            osc.connect(gain);
            gain.connect(this.masterGain!);
            osc.start();
            osc.stop(t + 0.5);
        };

        createNoiseOsc(100);
        createNoiseOsc(80);
        createNoiseOsc(150);
    });
  }

  playWhoosh() {
      this.safely(() => {
          if (!this.ctx || !this.masterGain) return;
          const t = this.ctx.currentTime;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          const filter = this.ctx.createBiquadFilter();

          osc.type = 'triangle';
          osc.frequency.setValueAtTime(200, t);
          osc.frequency.exponentialRampToValueAtTime(800, t + 0.3);

          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(500, t);
          filter.frequency.linearRampToValueAtTime(2000, t + 0.3);

          gain.gain.setValueAtTime(0.1, t);
          gain.gain.linearRampToValueAtTime(0, t + 0.3);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(this.masterGain);
          osc.start();
          osc.stop(t + 0.3);
      });
  }
}

export const audioService = new AudioService();