export enum View {
  HOME = 'HOME',
  GAME_SELECT = 'GAME_SELECT',
  GAME_SPACE = 'GAME_SPACE',
  GAME_MOON = 'GAME_MOON',
  SOLAR_SYSTEM = 'SOLAR_SYSTEM',
  AI_TOOLS = 'AI_TOOLS',
  IMAGE_EDITOR = 'IMAGE_EDITOR',
  VIDEO_GENERATOR = 'VIDEO_GENERATOR',
}

export interface Planet {
  name: string;
  color: string;
  size: number; // relative pixel size
  orbitRadius: number; // pixels
  speed: number; // seconds per orbit
  description: string;
  shortDescription: string;
}

export interface HighScores {
  spaceCluster: number;
  moonRover: number;
}