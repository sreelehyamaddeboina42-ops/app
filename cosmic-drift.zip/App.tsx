import React, { useState, useEffect } from 'react';
import Starfield from './components/Starfield';
import { View, HighScores } from './types';
import SpaceClusterGame from './components/SpaceClusterGame';
import MoonRoverGame from './components/MoonRoverGame';
import SolarSystem from './components/SolarSystem';
import { Rocket, Moon, Gamepad2, Globe, Volume2, VolumeX } from 'lucide-react';
import { audioService } from './services/audioService';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.HOME);
  const [highScores, setHighScores] = useState<HighScores>({ spaceCluster: 0, moonRover: 0 });
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('cosmicDriftHighScores');
    if (saved) {
      setHighScores(JSON.parse(saved));
    }
    // Initialize audio on first user interaction (browser policy)
    const handleInteract = () => {
        audioService.init();
        audioService.startAmbience();
        window.removeEventListener('click', handleInteract);
    };
    window.addEventListener('click', handleInteract);
    
    return () => window.removeEventListener('click', handleInteract);
  }, []);

  const updateHighScore = (game: keyof HighScores, score: number) => {
    if (score > highScores[game]) {
      const newScores = { ...highScores, [game]: score };
      setHighScores(newScores);
      localStorage.setItem('cosmicDriftHighScores', JSON.stringify(newScores));
    }
  };

  const toggleMute = () => {
    audioService.init(); // Ensure init if they click mute first
    audioService.resume();
    const muted = audioService.toggleMute();
    setIsMuted(muted);
    audioService.playClick();
  };

  const handleNav = (view: View) => {
    audioService.playClick();
    setCurrentView(view);
  };

  // --- Views ---

  const renderHome = () => (
    <div className="flex flex-col items-center justify-center min-h-screen z-10 p-4 safe-area-inset-top">
      <h1 className="text-5xl sm:text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 mb-8 md:mb-12 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)] animate-pulse tracking-tighter text-center select-none cursor-default">
        COSMIC DRIFT
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 w-full max-w-md md:max-w-4xl px-4">
        <button 
          onClick={() => handleNav(View.GAME_SELECT)}
          onMouseEnter={() => audioService.playHover()}
          className="group relative h-48 md:h-64 bg-slate-900/50 hover:bg-slate-800/80 border border-cyan-500/50 rounded-3xl p-6 md:p-8 transition-all transform hover:scale-105 hover:shadow-[0_0_40px_rgba(0,255,255,0.3)] flex flex-col items-center justify-center overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          <Gamepad2 size={48} className="text-cyan-400 mb-4 md:mb-6 md:w-16 md:h-16 group-hover:rotate-12 transition-transform duration-300" />
          <span className="text-3xl md:text-4xl font-bold text-white z-10">Start Game</span>
          <span className="text-cyan-200/60 text-sm md:text-lg mt-2">Arcade Mode</span>
        </button>

        <button 
          onClick={() => handleNav(View.SOLAR_SYSTEM)}
          onMouseEnter={() => audioService.playHover()}
          className="group relative h-48 md:h-64 bg-slate-900/50 hover:bg-slate-800/80 border border-purple-500/50 rounded-3xl p-6 md:p-8 transition-all transform hover:scale-105 hover:shadow-[0_0_40px_rgba(168,85,247,0.3)] flex flex-col items-center justify-center overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          <Globe size={48} className="text-purple-400 mb-4 md:mb-6 md:w-16 md:h-16 group-hover:spin-slow transition-transform" />
          <span className="text-3xl md:text-4xl font-bold text-white z-10">Solar System</span>
          <span className="text-purple-200/60 text-sm md:text-lg mt-2">3D Explorer</span>
        </button>
      </div>

      <div className="mt-12 md:mt-16 text-center text-slate-400 border border-slate-700 px-6 py-3 rounded-full backdrop-blur-sm bg-black/30 text-sm md:text-base flex flex-col sm:flex-row gap-2 sm:gap-6">
        <span>🏆 Space Score: <strong className="text-cyan-400">{highScores.spaceCluster}</strong></span>
        <span className="hidden sm:inline">|</span>
        <span>🏆 Moon Score: <strong className="text-yellow-400">{highScores.moonRover}</strong></span>
      </div>
    </div>
  );

  const renderGameSelect = () => (
    <div className="flex flex-col items-center justify-center min-h-screen z-10 p-4 animate-in fade-in duration-300 relative safe-area-inset-top">
       <button 
        onClick={() => handleNav(View.HOME)} 
        onMouseEnter={() => audioService.playHover()}
        className="absolute top-6 left-6 text-slate-400 hover:text-white transition flex items-center gap-2 font-bold z-20"
       >
         <HomeIcon /> <span className="hidden sm:inline">Back Home</span>
       </button>
       
       <h2 className="text-4xl md:text-5xl font-bold text-white mb-8 md:mb-16 drop-shadow-lg text-center mt-12 md:mt-0">Select Mission</h2>
       
       <div className="flex flex-col md:flex-row gap-6 md:gap-12 items-center justify-center w-full max-w-5xl">
          <div 
            onClick={() => handleNav(View.GAME_SPACE)}
            onMouseEnter={() => audioService.playHover()}
            className="w-full max-w-[320px] md:w-80 h-[400px] md:h-[450px] bg-gradient-to-b from-slate-800 to-slate-900 border-2 border-slate-700 hover:border-cyan-500 rounded-3xl p-6 md:p-8 cursor-pointer hover:-translate-y-4 transition-all shadow-2xl group relative overflow-hidden flex flex-col"
          >
             <div className="absolute inset-0 bg-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
             <div className="w-full h-40 md:h-48 bg-black/40 rounded-2xl mb-6 md:mb-8 flex items-center justify-center shadow-inner shrink-0">
                <Rocket size={60} className="text-cyan-500 md:w-20 md:h-20 group-hover:translate-y-[-10px] transition-transform duration-500" />
             </div>
             <h3 className="text-2xl md:text-3xl font-bold text-white mb-2 md:mb-4">Space Cluster</h3>
             <p className="text-slate-400 leading-relaxed text-sm md:text-base">Dodge asteroids and debris in deep space. Use Left/Right to survive.</p>
             <div className="mt-auto text-center text-cyan-400 font-bold tracking-widest uppercase text-sm">Best: {highScores.spaceCluster}</div>
          </div>

          <div 
            onClick={() => handleNav(View.GAME_MOON)}
            onMouseEnter={() => audioService.playHover()}
            className="w-full max-w-[320px] md:w-80 h-[400px] md:h-[450px] bg-gradient-to-b from-slate-800 to-slate-900 border-2 border-slate-700 hover:border-yellow-500 rounded-3xl p-6 md:p-8 cursor-pointer hover:-translate-y-4 transition-all shadow-2xl group relative overflow-hidden flex flex-col"
          >
             <div className="absolute inset-0 bg-yellow-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
             <div className="w-full h-40 md:h-48 bg-black/40 rounded-2xl mb-6 md:mb-8 flex items-center justify-center shadow-inner shrink-0">
                <Moon size={60} className="text-yellow-500 md:w-20 md:h-20 group-hover:scale-110 transition-transform duration-500" />
             </div>
             <h3 className="text-2xl md:text-3xl font-bold text-white mb-2 md:mb-4">Moon Rover</h3>
             <p className="text-slate-400 leading-relaxed text-sm md:text-base">Jump over craters on the lunar surface. Use Up/Down to navigate.</p>
             <div className="mt-auto text-center text-yellow-400 font-bold tracking-widest uppercase text-sm">Best: {highScores.moonRover}</div>
          </div>
       </div>
    </div>
  );

  return (
    <div className="relative w-full h-screen overflow-hidden font-sans text-slate-100 bg-[#050510]">
      {/* Persistent Background */}
      <Starfield />
      
      {/* Global Mute Control */}
      <button 
        onClick={toggleMute}
        className="fixed top-6 right-6 z-50 p-3 bg-slate-900/50 backdrop-blur-md rounded-full border border-slate-700 hover:bg-slate-800 transition text-white shadow-lg"
      >
        {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
      </button>

      {/* View Router */}
      {currentView === View.HOME && renderHome()}
      {currentView === View.GAME_SELECT && renderGameSelect()}
      
      {currentView === View.GAME_SPACE && (
        <SpaceClusterGame 
            onGameOver={(score) => updateHighScore('spaceCluster', score)} 
            highScore={highScores.spaceCluster}
            onExit={() => handleNav(View.HOME)}
        />
      )}
      
      {currentView === View.GAME_MOON && (
        <MoonRoverGame 
            onGameOver={(score) => updateHighScore('moonRover', score)} 
            highScore={highScores.moonRover}
            onExit={() => handleNav(View.HOME)}
        />
      )}
      
      {currentView === View.SOLAR_SYSTEM && (
        <SolarSystem onBack={() => handleNav(View.HOME)} />
      )}
    </div>
  );
};

// Simple Home Icon component for internal use
const HomeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
    <polyline points="9 22 9 12 15 12 15 22"/>
  </svg>
);

export default App;