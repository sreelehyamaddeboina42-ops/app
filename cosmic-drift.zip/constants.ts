import { Planet } from './types';

export const PLANETS: Planet[] = [
  {
    name: "Mercury",
    color: "#A5A5A5",
    size: 10,
    orbitRadius: 95,
    speed: 4,
    shortDescription: "The Swift Planet",
    description: "The smallest planet in our solar system and closest to the Sun. It is only slightly larger than Earth's Moon. Mercury has a cratered surface similar to the Moon and no atmosphere to retain heat."
  },
  {
    name: "Venus",
    color: "#E3BB76",
    size: 18,
    orbitRadius: 145,
    speed: 7,
    shortDescription: "The Morning Star",
    description: "Second planet from the Sun. It spins in the opposite direction to most other planets and is the hottest planet. Its surface pressure is intense enough to crush a car."
  },
  {
    name: "Earth",
    color: "#4F86F7",
    size: 20,
    orbitRadius: 200,
    speed: 10,
    shortDescription: "The Blue Planet",
    description: "Our home world. The only place we know of so far that's inhabited by living things. It is the densest planet in the solar system."
  },
  {
    name: "Mars",
    color: "#E25822",
    size: 16,
    orbitRadius: 250,
    speed: 15,
    shortDescription: "The Red Planet",
    description: "A cold desert world. It is red because of rusty iron in the ground. Home to Olympus Mons, the largest volcano in the solar system."
  },
  {
    name: "Jupiter",
    color: "#D6A566",
    size: 45,
    orbitRadius: 360,
    speed: 25,
    shortDescription: "The Gas Giant",
    description: "More than twice as massive as all the other planets combined. The Great Red Spot is a giant storm. It spins faster than any other planet, with a day lasting only about 10 hours."
  },
  {
    name: "Saturn",
    color: "#F4D03F",
    size: 38,
    orbitRadius: 460,
    speed: 35,
    shortDescription: "The Ringed Jewel",
    description: "Adorned with a dazzling system of complex rings. It is unique among the planets. Saturn is the least dense of all planets and is the only one less dense than water."
  },
  {
    name: "Uranus",
    color: "#73C6B6",
    size: 28,
    orbitRadius: 550,
    speed: 50,
    shortDescription: "The Ice Giant",
    description: "It rotates at a nearly 90-degree angle from the plane of its orbit. It has faint rings and many moons. Its blue-green color is caused by methane gas in its atmosphere."
  },
  {
    name: "Neptune",
    color: "#5DADE2",
    size: 28,
    orbitRadius: 640,
    speed: 65,
    shortDescription: "The Windy Planet",
    description: "The first planet located through mathematical calculations rather than by telescope. It has supersonic winds. It takes 165 Earth years to complete one orbit around the Sun."
  }
];